package com.example.coursework2;

import java.util.ArrayList;

/**
 * Class that represents a perishable item.
 * This item can expire and has a list of sorting offices it passes through.
 */
public  class Perishable implements Deliverable {
    private SortingOffice sender;
    private SortingOffice recipient;
    private boolean expired = false;
    private ArrayList<SortingOffice> locations;

    /**
     * Constructor that constructs a new Perishable item with the given sender and recipient sorting offices.
     *
     * @param sender the sorting office sending the item
     * @param recipient the sorting office receiving the item
     */
    public Perishable(SortingOffice sender, SortingOffice recipient) {
        this.sender = sender;
        this.recipient = recipient;
        this.locations = new ArrayList<>();
    }

    /**
     * Method that processes the item as it passes through sorting office.
     * The sorting office is then added to the list of locations.
     *
     * @param sortingOffice the sorting office through which the item passes
     */
    @Override
    public void process(SortingOffice sortingOffice) {
        locations.add(sortingOffice);

    }

    /**
     * Getter method that returns the sender sorting office of the item.
     *
     * @return the sender sorting office
     */
    @Override
    public SortingOffice getSender() {
        return sender;
    }

    /**
     * Getter method that returns the recipient sorting office of the item.
     *
     * @return the recipient sorting office
     */
    @Override
    public SortingOffice getRecipient() {
        return recipient;
    }

    /**
     * String method that returns a receipt for the item.
     * Currently, this method returns null .
     *
     * @return  string receipt as null
     */
    @Override
    public String getReceipt() {
        return null;
    }

    /**
     * Setter method that sets the expiration status of the item.
     *
     * @param expired true if the item has expired, false
     */
    public void setExpired(boolean expired) {
        this.expired = expired;
    }

    /**
     * Method that checks if the item has expired.
     *
     * @return true if the item is expired, false if not
     */
    public boolean isExpired() {
        return expired;
    }

    /**
     * Method that returns the list of all the sorting offices tha the item has passed through.
     *
     * @return an ArrayList of SortingOffice objects representing the locations of the item
     */
    public ArrayList<SortingOffice> getLocations() {
        return locations;
    }
}
