package com.example.coursework2;
/**
 * Class that Represents a item that is non perishable.
 * It may be fragile and can be broken during the delivery process depending on a specific route.
 */
public class NonPerishable implements Deliverable {
    private SortingOffice sender;
    private SortingOffice recipient;
    private double weight;
    private boolean fragile;
    private boolean broken = false; //Initialize the broken boolean as false will be changed if not broken.
    private static final String HAZARDOUS_ROUTE = "X300Y440CIreland";


    /****
     * Constructor that constructs a NonPerishable item with the specified sender, recipient,
     * weight, and fragility.
     *
     * @param sender    the SortingOffice that is sending the item
     * @param recipient the SortingOffice that is receiving the item
     * @param weight    the weight of the item
     * @param fragile   whether or not the item is fragile
     *
     * */
    public NonPerishable(SortingOffice sender, SortingOffice recipient, double weight, boolean fragile) {
        this.sender = sender;
        this.recipient = recipient;
        this.weight = weight;
        this.fragile = fragile;
    }

    /**
     * Getter method that gets the sender of the item.
     *
     * @return the SortingOffice sender
     */
    @Override
    public SortingOffice getSender() {
        return sender;
    }

    /**
     * Getter method that gets the recipient of the item.
     *
     * @return the SortingOffice recipient
     */
    @Override
    public SortingOffice getRecipient() {
        return recipient;
    }

    /**
     * String method that returns a delivery receipt message.
     * <p>
     * The message depends on the item's condition and fragility.
     *
     * @return the delivery receipt string
     */
    @Override
    public String getReceipt() {
        if (broken) {
            return "Fragile Non-Perishable delivered to " + getRecipient().getLocation() + ". Item is broken.";
        }

        if (fragile) {
            return "Fragile Non-Perishable delivered to " + getRecipient().getLocation() + ".";
        }

        return "Non-Perishable delivered to " + getRecipient().getLocation() + ".";
    }


    /**
     * Method thaat checks whether the item has been broken during delivery.
     *
     * @return true if broken, false otherwise
     */
    public boolean isBroken() {
        return broken;
    }

    /**
     * Process method that processes the delivery at a given sorting office and marks the item as broken
     * if it went past the hazardous route.
     *
     * @param sortingOffice the sorting office processing the item
     */
    public void process(SortingOffice sortingOffice) {
        if (fragile && sortingOffice.toString().contains(HAZARDOUS_ROUTE)) {
            broken = true;
        }
    }
}