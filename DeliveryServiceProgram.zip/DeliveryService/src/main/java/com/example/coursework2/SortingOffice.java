package com.example.coursework2;

import java.util.ArrayList;

/**
 *  Class that represents a Sorting Office object.
 *  Each Sorting Office has ID, location, country, and a list of postcodes it handles.
 *  It can also have connections to other Sorting Offices.
 *  */
public class SortingOffice {
    private static int nextId = 11;
    private final int id;
    private final int x;
    private final int y;
    private final String location;
    private final String country;
    private final boolean international;
    private final ArrayList<String> postcodes;
    private final ArrayList<SortingOffice> connections;

    /**
     * Constructor that constructs a Sorting Office with given coordinates(x and y),
     * country, international flag, and postcodes.
     *
     * @param x          the x-coordinate of the sorting office
     * @param y          the y-coordinate of the sorting office
     * @param country    the country of the sorting office
     * @param international indicates if the sorting office is international
     * @param postcodes  a list of postcodes handled by the sorting office
     */
    public SortingOffice(int x, int y,  String country, boolean international, ArrayList<String> postcodes) {
        this.id = nextId++;
        this.x = x;
        this.y = y;
        this.country = country;
        this.international = international;
        this.postcodes = postcodes;
        this.connections = new ArrayList<>();
        this.location = "X" + x + "Y" + y + "C" + country;
     }

    /**
     * Getter method that gets the x-coordinate of the sorting office.
     *
     * @return the x-coordinate
     */
    public int getX() {
        return x;
    }

    /**
     * Getter method that gets the y-coordinate of the sorting office.
     *
     * @return the x-coordinate
     */
    public int getY() {
        return y;
    }

    /**
     * Boolean thaat returns whether or not the sorting office is international.
     *
     * @return true if international, false otherwise
     */
    public boolean isInternational() {
        return international;
    }

    /**
     * Getter method that gets the location of the sorting office.
     *
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Getter method that gets the unique ID of the sorting office.
     *
     * @return the ID
     */
    public int getId() {
        return id;
    }

    /**
     * Getter method that gets the country of the sorting office.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Getter method that gets the list of postcodes by the sorting office.
     *
     * @return the list of postcodes
     */
    public ArrayList<String> getPostcodes() {
        return postcodes;
    }

    /**
     * Getter method that gets the list of sorting offices that are connected to the sorting office.
     *
     * @return the list of sorting offices
     */
    public ArrayList<SortingOffice> getConnections() {
        return connections;
    }

    /**
     * Method that adds a connection from this sorting office to another sorting office.
     * The connection is only added if not already existing.
     *
     * @param office the sorting office to connect to
     */
    public void addConnection(SortingOffice office) {
        if (!connections.contains(office)) {
            connections.add(office);
        }
    }

    /**
     * Method that returns a string representation of the Sorting Office, including location,
     * international status, and postcodes.
     *
     * @return a string of the Sorting Office
     */
    @Override
    public String toString() {
        StringBuilder string = new StringBuilder();
        string.append(location);
        string.append(international);
        for (String postcode : postcodes) {
            string.append(postcode);
        }
        return string.toString();
    }
}


