package com.example.coursework2;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Stack;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;


/**
 * Class to hold data that is added to the "database".
 * You may add methods to this class.
 */
public class Data {

    /**
     * Attributes to save our data to the "database"
     */
    private static ArrayList<SortingOffice> sortingOffices = new ArrayList<>();
    private static Stack<Deliverable> deliverables = new Stack<>();
    private static Stack<Deliverable> processedDeliverables = new Stack<>();


    /**
     * Method to return the Stack of deliverables
     *
     * @return stack of deliverables
     */
    public static Stack<Deliverable> getDeliverables() {
        return deliverables;
    }

    /**
     * Method to return the sorting offices
     *
     * @return array list of sorting offices
     */
    public static ArrayList<SortingOffice> getSortingOffices() {
        return sortingOffices;
    }

    /**
     * Method to return the completed deliverables.
     *
     * @return stack of completed deliverables.
     */
    public static Stack<Deliverable> getProcessedDeliverables() {
        return processedDeliverables;
    }

    /**
     * DO NOT EDIT ANY CODE ABOVE THIS COMMENT. You may need to write additional methods below.
     **/

    /**
     * Method that finds and returns the sorting office based on the given postcode.
     *
     * @param postcode the postcode that is being searched for
     * @return the SortingOffice with that specific postcode, or null if it hasn't been found.
     */
    public static SortingOffice findSortingOffice(String postcode) {
        for (SortingOffice office : sortingOffices) {
            if (office.getPostcodes().contains(postcode)) {
                return office;
            }
        }
        return null;
    }

    /**
     * Method that finds and returns the sorting office based on a given ID.
     *
     * @param id the ID of the sorting office
     * @return the SortingOffice with that specific ID, or null if not found
     */
    public static SortingOffice findSortingOffice(int id) {
        for (SortingOffice office : sortingOffices) {
            if (office.getId() == id) {
                return office;
            }
        }
        return null;
    }

    /**
     * Method that reads the sorting office data from the file and populates
     * the list.
     */
    public static void readSortingOffices() {
        try {
            File sortingOfficeFile = new File("sortingOffices.txt");
            Scanner fileReader = new Scanner(sortingOfficeFile);

            while (fileReader.hasNextLine()) {
                Scanner lineReader = new Scanner(fileReader.nextLine());

                int x = lineReader.nextInt();
                int y = lineReader.nextInt();
                String country = lineReader.next();
                boolean international = lineReader.nextBoolean();
                lineReader.useDelimiter(",");

                ArrayList<String> postcodes = new ArrayList<>();
                while (lineReader.hasNext()) {
                    postcodes.add(lineReader.next().trim());
                }

                SortingOffice office = new SortingOffice(x, y, country, international, postcodes);
                sortingOffices.add(office);

                lineReader.close();
            }
            fileReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File Was Not Found");
        }
    }

    /**
     * Method that reads deliverables data from the file and populates
     * the deliverables stack.
     */
    public static void readingDeliverables() {
        try {
            File deliverablesFile = new File("deliverables.csv");
            Scanner fileReader = new Scanner(deliverablesFile);

            while (fileReader.hasNextLine()) {
                Scanner lineReader = new Scanner(fileReader.nextLine());
                lineReader.useDelimiter(",");
                String sender = lineReader.next();
                String recipient = lineReader.next();
                String itemType = lineReader.next();
                SortingOffice senderOffice = findSortingOffice(sender);
                SortingOffice recipientOffice = findSortingOffice(recipient);
                Deliverable deliverable;
                if (itemType.equals("NonPerishable")) {
                    double weight = lineReader.nextDouble();
                    boolean fragile = lineReader.nextBoolean();
                    deliverable = new NonPerishable(senderOffice, recipientOffice, weight, fragile);
                } else if (itemType.equals("Plant")) {
                    deliverable = new Plant(senderOffice, recipientOffice);
                } else {
                    deliverable = new Produce(senderOffice, recipientOffice);
                }
                deliverables.push(deliverable);
                lineReader.close();
            }
            fileReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File Was Not Found");
        }
    }

    /**
     * Method that adds connections between sorting offices based on international status and country.
     *
     * Needs to connect each international sorting office to every sorting office that is in the same country
     *
     */
    public static void addConnections() {
        for (SortingOffice sortingOfficeInternational : sortingOffices) {
            if (!sortingOfficeInternational.isInternational()) {
                continue;
            }

            String internationalCountry = sortingOfficeInternational.getCountry();

            for (SortingOffice countryOffice : sortingOffices) {
                if (sortingOfficeInternational.getId() == countryOffice.getId()) {
                    continue;
                }

                if (countryOffice.getCountry().equals(internationalCountry) || countryOffice.isInternational()) {
                    if (!sortingOfficeInternational.getConnections().contains(countryOffice)) {
                        sortingOfficeInternational.addConnection(countryOffice);
                        countryOffice.addConnection(sortingOfficeInternational);
                    }
                }
            }
            for (SortingOffice otherInternationalOffice : sortingOffices) {

                if (sortingOfficeInternational.getId() == otherInternationalOffice.getId() || !otherInternationalOffice.isInternational()) {
                    continue;
                }
                sortingOfficeInternational.addConnection(otherInternationalOffice);
                otherInternationalOffice.addConnection(sortingOfficeInternational);
            }
        }
    }

    /**
     * Method that helps to write receipts for all processed deliverables to a file named "receipts.txt".
     */
    public static void printReceipts() {
        try (PrintWriter writer = new PrintWriter("receipts.txt")) {
            for (Deliverable item : getProcessedDeliverables()) {
                writer.println(item.getReceipt());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Created"  + e.getMessage());
        }
    }
}
