package com.example.coursework2;

/**
 * Subclass of Perishable Class that represents a perishable item that can expire.
 * It extends from Perishable Class.
 *
 * The produce can be processed at different sorting offices, with its current location
 * being updated at each office.
 *
 */
public class Produce extends Perishable {
    private String currentLocation;
    private String trackingLocation;

    /**
     * Constructor that constructs a Produce with a sender and recipient.
     * Initializes the current location and tracking location to empty strings.
     *
     * @param sender    The sorting office that is sending the produce.
     * @param recipient The sorting office that will receive the produce.
     */
    public Produce(SortingOffice sender, SortingOffice recipient) {
        super(sender, recipient);
        this.currentLocation = "";
        this.trackingLocation = "";
    }

    /**
     * Method that processes produce as it moves through offices.
     * Updates the current and tracking locations based on the office its gone through.
     *
     * @param sortingOffice The sorting office that the produce is at.
     */
    @Override
    public void process(SortingOffice sortingOffice) {
        getLocations().add(sortingOffice);
        currentLocation = sortingOffice.getLocation();

        if (trackingLocation.equals("")) {
            trackingLocation = currentLocation;
        } else {
            trackingLocation += "," + currentLocation;
        }
    }

    /**
     * Getter method that gets the sender sorting office of the produce.
     *
     * @return The sorting office that sends the produce.
     */
    @Override
    public SortingOffice getSender() {
        return super.getSender();
    }

    /**
     * Getter method that gets the recipient sorting office of the produce.
     *
     * @return The sorting office that will receive produce.
     */
    @Override
    public SortingOffice getRecipient() {
        return super.getRecipient();
    }

    /**
     * String method that returns a receipt for the produce,
     * It will also send a warning message if the produce has unfortunately expired.
     *
     * @return A string containing the receipt for the produce delivery.
     */
    @Override
    public String getReceipt() {
        if (isExpired()) {
            return "WARNING! Expired Produce delivered to " + getRecipient().getLocation() +
                    ". Produce route:" + trackingLocation + ".";
        }
        return "Produce delivered to " + getRecipient().getLocation() +
                ". Produce route: " + trackingLocation + ".";
    }
}