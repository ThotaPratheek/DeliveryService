package com.example.coursework2;

/**
 * Subclass of Perishable Class that represents a plant that can expire.
 *
 * The class extends the Perishable class and helps to adds logic specifically for processing plants
 * and checking expiration.
 */
public class Plant extends Perishable {

    /**
     * Constructor that constructs a Plant with a sender and recipient sorting office.
     *
     * @param sender    the SortingOffice where the plant is being sent from
     * @param recipient the SortingOffice where the plant is being delivered to
     */
    public Plant(SortingOffice sender, SortingOffice recipient) {
        super(sender, recipient);
    }

    /**
     * Getter method that gets the sender sorting office of the plant.
     *
     * @return the SortingOffice where the plant is being sent
     */
    @Override
    public SortingOffice getSender() {
        return super.getSender();
    }

    /**
     * Getter method that gets the recipient sorting office of the plant.
     *
     * @return the SortingOffice where the plant is being received
     */
    @Override
    public SortingOffice getRecipient() {
        return super.getRecipient();
    }

    /**
     * Method that processes plant by adding the current sorting office to the list.
     *
     * If the plant has passed through more than 3 offices, it expires.
     *
     * @param sortingOffice the SortingOffice currently processing the plant
     */
    @Override
    public void process(SortingOffice sortingOffice) {
        getLocations().add(sortingOffice);
        if (getLocations().size() > 3) {
            setExpired(true);
        }
    }

    /**
     * Getter method that gets a receipt message indicating whether or not the plant expired.
     *
     * @return a string receipt message for the plant
     */
    @Override
    public String getReceipt() {
        if (isExpired()) {
            return "WARNING! Expired Plant delivered to " + getRecipient().getLocation() + ".";
        }
        return "Plant delivered to " + getRecipient().getLocation() + ".";
    }
}
