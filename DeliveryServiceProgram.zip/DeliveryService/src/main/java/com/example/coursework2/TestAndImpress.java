package com.example.coursework2;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * The TestAndImpress class tests various functionalities related to all the classes in the coursework
 */

public class TestAndImpress {
    private static SortingOffice office1;
    private static SortingOffice office2;
    private static NonPerishable nonPerishable1;
    private static NonPerishable nonPerishableFragile;

    /**
     * The main method that calls all the testing methods.
     * @param args command line arguments
     */
    public static void main(String[] args) {
        initializeTestingData();
        testingTask1();
        testingTask2();
        testingTask3();
        testingTask4();
        testingTask5();
        testingTask6();
        testingTask7();
        testingTask8();
    }

    /**
     * Method that initializes all the test data for SortingOffice and NonPerishable objects.
     *
     */
    public static void initializeTestingData() {
        ArrayList<String> postcodes1 = new ArrayList<>(Arrays.asList("SA", "PL"));
        office1 = new SortingOffice(100, 100, "Wales", true, postcodes1);
        ArrayList<String> postcodes2 = new ArrayList<>(Arrays.asList("LA", "NJ"));
        office2 = new SortingOffice(200, 200, "England", false, postcodes2);
        nonPerishable1 = new NonPerishable(office1, office2, 1.5, false);
        nonPerishableFragile = new NonPerishable(office1, office2, 0.5, true);
    }

    //Method That Tests All Elements Of Task 1.
    public static void testingTask1() {
        System.out.println("Task 1 Tests");
        //Testing Office 1 ID
        int expectedId = 11;
        int actualId = office1.getId();
        System.out.println("Expected Output = Office 1 ID: " + expectedId);
        System.out.println("Actual Output = Office 1 ID: " + actualId);
        if (actualId == expectedId) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing Office 2 ID
        int expectedIdForOffice2 = 12;
        int actualIdForOffice2 = office2.getId();
        System.out.println("Expected Output = Office 2 ID: " + expectedIdForOffice2);
        System.out.println("Actual Output = Office 2 ID: " + actualIdForOffice2);
        if (actualId == expectedId) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        String expectedLocation = "X100Y100CWales";
        String actualLocation = office1.getLocation();
        System.out.println("Expected Output Location: " + expectedLocation);
        System.out.println("Actual Output Location: " + actualLocation);

        if (expectedLocation.equals(actualLocation)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        int expectedOffice1GetX = 100;
        int actualOffice1GetX = office1.getX();
        int expectedOffice1GetY = 100;
        int actualOffice1GetY = office1.getY();
        int expectedOffice2GetX = 200;
        int actualOffice2GetX = office2.getX();
        int expectedOffice2GetY = 200;
        int actualOffice2GetY = office2.getY();
        System.out.println("Expected Output Office 1 X: " + expectedOffice1GetX);
        System.out.println("Actual Output Office 1 X: " + actualOffice1GetX);
        if (expectedOffice1GetX == actualOffice1GetX) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        System.out.println("Expected Output Office 1 Y: " + expectedOffice1GetY);
        System.out.println("Actual Output Office 1 Y: " + actualOffice1GetY);
        if (expectedOffice1GetY == actualOffice1GetY) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        System.out.println("Expected Output Office 2 X: " + expectedOffice2GetX);
        System.out.println("Actual Output Office 2 X: " + actualOffice2GetX);
        if (expectedOffice2GetX == actualOffice2GetX) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        System.out.println("Expected Output Office 2 Y: " + expectedOffice2GetY);
        System.out.println("Actual Output Office 2 Y: " + actualOffice2GetY);
        if (expectedOffice2GetY == actualOffice2GetY) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Intializing Expected vs Actual Values
        boolean expectedInternationalValueOffice1 = true;
        boolean actualInternationalValueOffice1 = office1.isInternational();
        boolean expectedInternationValueOffice2 = false;
        boolean actualInternationalValueOffice2 = office2.isInternational();

        //Testing Office 1 isInternational
        System.out.println("Expected Office 1 isInternational: " + expectedInternationalValueOffice1);
        System.out.println("Actual Office 1 isInternational: " + actualInternationalValueOffice1);
        if (expectedInternationalValueOffice1 == actualInternationalValueOffice1) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing Office 2 isInternational
        System.out.println("Expected Office 2 isInternational: " + expectedInternationValueOffice2);
        System.out.println("Actual Office 2 isInternational: " + actualInternationalValueOffice2);
        if (expectedInternationValueOffice2 == actualInternationalValueOffice2) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing Office 1 Initial Connections Size
        int expectedInitialConnectionsSize = 0;
        int actualInitialConnectionsSize = office1.getConnections().size();
        System.out.println("Office 1 Expected Connections: " + expectedInitialConnectionsSize);
        System.out.println("Office 1 Actual Connections: " + actualInitialConnectionsSize);
        if (actualInitialConnectionsSize == expectedInitialConnectionsSize) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing Office 1 Connections Size After Adding
        office1.addConnection(office2);
        int expectedConnectionsSizeAfterAdd = 1;
        int actualConnectionsSizeAfterAdd = office1.getConnections().size();
        System.out.println("Office 1 Expected Connections: " + expectedConnectionsSizeAfterAdd);
        System.out.println("Office 1 Actual Connections: " + actualConnectionsSizeAfterAdd);
        if (actualConnectionsSizeAfterAdd == expectedConnectionsSizeAfterAdd) {
            System.out.println("Test Passed");
        } else System.out.println("Test Failed");
        System.out.println("--------------------------------------");

        //Testing Office 1 toString
        String expectedToString = "X100Y100CWalestrueSAPL";
        String actualToString = office1.toString();
        System.out.println("Office 1 Expected toString: " + expectedToString);
        System.out.println("Office 1 Actual toString: " + actualToString);
        if (expectedToString.equals(actualToString)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");
    }

    //Method That Tests Task 2.
    public static void testingTask2() {
        System.out.println("Task 2 Tests");

        //Testing Sender And Location
        String expectedSender = "X100Y100CWales";
        String actualSender = nonPerishable1.getSender().getLocation();
        System.out.println("Expected NonPerishable 1 Sender Location: " + expectedSender);
        System.out.println("Actual NonPerishable 1 Sender Location: " + actualSender);
        if (expectedSender.equals(actualSender)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing Recipient
        String expectedRecipient = "X200Y200CEngland";
        String actualRecipient = nonPerishable1.getRecipient().getLocation();
        System.out.println("Expected NonPerishable 1 Recipient Location: " + expectedRecipient);
        System.out.println("Actual NonPerishable 1 Recipient Location: " + actualRecipient);
        if (expectedRecipient.equals(actualRecipient)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing process method
        SortingOffice sortingOffice = new SortingOffice(300, 440, "Ireland", false, new ArrayList<>());
        NonPerishable fragileItem = new NonPerishable(office1, office2, 0.5, true);
        fragileItem.process(sortingOffice);
        System.out.println("Test Case: NonPerishable process() - fragile at bad office");
        System.out.println("Expected Broken Status: true");
        System.out.println("Actual Broken Status: " + fragileItem.isBroken());
        if (fragileItem.isBroken()) System.out.println("Test Passed");
        else System.out.println("Test Failed");
        System.out.println("--------------------------------------");

        //Testing getReceipt method - non-fragile
        String expectedReceiptNonFragile = "Non-Perishable delivered to X200Y200CEngland.";
        String actualReceiptNonFragile = nonPerishable1.getReceipt();
        System.out.println("Expected Receipt: " + expectedReceiptNonFragile);
        System.out.println("Actual Receipt: " + actualReceiptNonFragile);
        if (expectedReceiptNonFragile.equals(actualReceiptNonFragile)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing getReceipt method - fragile, not broken
        String expectedReceiptFragile = "Fragile Non-Perishable delivered to X200Y200CEngland.";
        String actualReceiptFragile = nonPerishableFragile.getReceipt();
        System.out.println("Expected Receipt: " + expectedReceiptFragile);
        System.out.println("Actual Receipt: " + actualReceiptFragile);
        if (expectedReceiptFragile.equals(actualReceiptFragile)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        //Testing getReceipt method - fragile, broken
        System.out.println("Test Case: NonPerishable getReceipt() - fragile, broken");
        NonPerishable brokenItem = new NonPerishable(office1, office2, 0.7, true);
        brokenItem.process(sortingOffice);
        String expectedReceiptBroken = "Fragile Non-Perishable delivered to X200Y200CEngland. Item is broken.";
        String actualReceiptBroken = brokenItem.getReceipt();
        System.out.println("Expected Receipt: " + expectedReceiptBroken);
        System.out.println("Actual Receipt: " + actualReceiptBroken);
        if (expectedReceiptBroken.equals(actualReceiptBroken)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

    }

    //Method that tests everything from Task 3
    public static void testingTask3() {
        System.out.println("Task 3 Tests");
        // Testing Perishable attributes initialization
        SortingOffice sender = new SortingOffice(1, 1, "SA", false, new ArrayList<>());
        SortingOffice recipient = new SortingOffice(2, 2, "RA", false, new ArrayList<>());
        Perishable perishable = new Perishable(sender, recipient);

        System.out.println("Expected Expired Status: false");
        System.out.println("Actual Expired Status: " + perishable.isExpired());
        if (!perishable.isExpired()){
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        System.out.println("Expected Locations Size: 0");
        System.out.println("Actual Locations Size: " + perishable.getLocations().size());
        if (perishable.getLocations().size() == 0) {
            System.out.println("Test Passed");
        } else{
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        // Testing process method of Perishable
        SortingOffice office3 = new SortingOffice(3, 3, "Office3", false, new ArrayList<>());
        perishable.process(office3);
        System.out.println("Expected Locations Size After Process: 1");
        System.out.println("Actual Locations Size After Process: " + perishable.getLocations().size());
        if (perishable.getLocations().size() == 1 ){
            System.out.println("Test Passed");
        } else{
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");
    }

    //Method that tests task 4
    public static void testingTask4() {
        System.out.println("Task 4 Tests");
        System.out.println("--------------------------------------");
    }

    //Method that tests task 5
    public static void testingTask5() {
        System.out.println("Task 5 Tests");

        Data.getSortingOffices().add(office1);
        Data.getSortingOffices().add(office2);

        // Test case 1: Find office by postcode
        String testPostcode = "SA";
        SortingOffice foundByPostcode = Data.findSortingOffice(testPostcode);
        System.out.println("Find by Postcode SA");
        System.out.println("Expected Location: " + foundByPostcode);
        System.out.println("Actual Location: " + office1);
        if (foundByPostcode != null && foundByPostcode.getLocation().equals(office1.getLocation())) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");

        // Test case 2: Find office by ID
        int testId = office2.getId();
        SortingOffice foundById = Data.findSortingOffice(testId);
        System.out.println("Find By ID");
        System.out.println("Expected Location: " + office2);
        System.out.println("Actual Location: " + foundById);
        if (foundById != null && foundById.getLocation().equals(office2.getLocation())) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }
        System.out.println("--------------------------------------");
    }
    //Method that tests task 6
    public static void testingTask6() {
        System.out.println("Task 6 Tests");
        System.out.println("--------------------------------------");

    }
    //Method that tests task 7
    public static void testingTask7() {
        System.out.println("Task 7 Tests");
         System.out.println("--------------------------------------");

    }

    //Method that tests task 8
    public static void testingTask8() {
        System.out.println("Task 8 Tests");
        System.out.println("Already Tested Receipts In Task 2 Tests");
    }
}